# Building the .aab — three ways

This folder is a complete, ready-to-compile Android project (Trusted Web Activity,
package `com.stanfordclinicandherbshop.app`, target SDK 36, version 1.0.0/code 1).
It could not be compiled inside Claude's sandbox (Google's SDK download servers are
blocked there), so pick ONE path below. **Path A is the recommended one.**

---

## Path A — GitHub Actions builds it for you (recommended)

Prereq: this project pushed to a GitHub repo (private is fine).

1. Copy this whole `app-android/` folder into your repo (e.g. at `android/`), including
   the hidden `.github/workflows/build-aab.yml` — move that file to the repo root's
   `.github/workflows/` folder.
2. *(Optional but recommended — produces a fully signed bundle)* In GitHub:
   Settings → Secrets and variables → Actions → New repository secret. Add three:
   - `UPLOAD_KEYSTORE_B64` — the keystore encoded as text:
     - Mac: `base64 -i upload-keystore.jks | pbcopy`
     - Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("upload-keystore.jks")) | Set-Clipboard`
   - `KEYSTORE_PASSWORD` — the password you chose
   - `KEY_ALIAS` — `upload`
   GitHub encrypts these; they are not files in the repo. If you'd rather not put the
   key there at all, skip this step — the build then produces an UNSIGNED .aab and you
   sign it locally (one `jarsigner` command, see KEYSTORE.md).
3. GitHub → Actions tab → "Build Android App Bundle" → Run workflow.
4. When it finishes (~3–5 min), download the artifacts: the `.aab` (for Play Console)
   and the universal `.apk` (for sideload testing on your phone).

## Path B — build on your own computer

1. Install JDK 17 (see KEYSTORE.md) and Node LTS (nodejs.org).
2. `npm i -g @bubblewrap/cli`
3. In this folder: `bubblewrap build`
   - First run: let Bubblewrap download the Android SDK when it offers (~1 GB).
   - It reads `twa-manifest.json`, asks for your keystore path/passwords
     (point it at your `upload-keystore.jks`), and produces:
     - `app-release-bundle.aab` — upload this to Play Console
     - `app-release-signed.apk` — sideload this to test
4. Reproducible from absolute scratch (no Bubblewrap):
   ```
   ./gradlew bundleRelease        # → app/build/outputs/bundle/release/app-release.aab (unsigned)
   jarsigner -keystore /path/to/upload-keystore.jks app-release.aab upload
   ```

## Path C — PWABuilder (zero-toolchain fallback)

Only if A and B both fail you. After the Netlify manifest/icons are deployed:
pwabuilder.com → enter the site URL → Package for stores → Android. Use package ID
`com.stanfordclinicandherbshop.app` EXACTLY (it's permanent), and choose "Use mine"
for the signing key if it lets you upload one. Their servers run this same Bubblewrap
tooling. Less control over versions/settings — treat as a backup.

---

## Version bumps (future releases)

Edit `twa-manifest.json`: increase `appVersionCode` by 1 (and `appVersionName` as you
like), run `bubblewrap update` then rebuild — or in Path A just edit the same two
values and re-run the workflow.
