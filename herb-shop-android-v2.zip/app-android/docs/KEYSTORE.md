# Signing key — you create it, you keep it

You will create ONE keystore file on your own computer. It never goes in any repo,
any cloud drive you share, or any chat. Google never sees it.

## One-time setup (about 3 minutes)

`keytool` ships with Java. If you don't have Java:

- **Windows:** `winget install EclipseAdoptium.Temurin.17.JDK` (then reopen the terminal)
- **Mac:** `brew install --cask temurin@17`

Then, in a folder you'll remember (e.g. `Documents/herb-shop-signing/`):

```
keytool -genkeypair -v -keystore upload-keystore.jks -alias upload -keyalg RSA -keysize 2048 -validity 9125 -dname "CN=Stanford Clinic & Herb Shop, O=Stanford Clinic & Herb Shop, L=Lucedale, ST=MS, C=US"
```

It asks you to invent a keystore password (twice). Pick a strong one and save it in a
password manager immediately. If it also asks for a key password, press Enter to reuse
the same one.

## Get the fingerprint (needed for assetlinks.json)

```
keytool -list -v -keystore upload-keystore.jks -alias upload | findstr SHA256     (Windows)
keytool -list -v -keystore upload-keystore.jks -alias upload | grep SHA256       (Mac)
```

Copy the whole `SHA256: AB:CD:...` line and paste it to Claude (or into
`make-assetlinks.sh`). The fingerprint is PUBLIC — safe to share anywhere.
The keystore file and password are the secrets.

## Sign the app bundle (each release)

```
jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 -keystore upload-keystore.jks app-release.aab upload
```

(If you use the GitHub Actions build with secrets, this happens in CI and you skip this.)

## How Play App Signing works — read once

There are TWO keys:

1. **App signing key — Google creates and holds it.** It signs what customers actually
   download. You never touch it. Because Google holds it, it can't be lost.
2. **Upload key — the one you just made.** It only proves uploads come from you.

On your FIRST upload, Play Console asks about "Play App Signing" — accept the default
("Google-generated key"). After that first upload, Play Console shows the **app signing
key's SHA-256** under *Test and release → Setup → App signing (App integrity)*. **That
fingerprint must be added to assetlinks.json too** — the version of the app people
install from Play is signed with Google's key, so the website has to vouch for both.

## What you must never lose vs. what's recoverable

| Item | If lost |
|---|---|
| Upload keystore + password | Annoying but fixable — Play Console has an "upload key reset" request (takes a few days) |
| Package ID `com.stanfordclinicandherbshop.app` | Can NEVER change — it's the app's permanent identity |
| App signing key | Google holds it — you can't lose it |

Back the keystore up to two places (password manager attachment + a USB stick in the
shop safe is plenty).
