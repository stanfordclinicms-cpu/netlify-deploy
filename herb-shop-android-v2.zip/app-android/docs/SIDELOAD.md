# Testing on a real Android phone

You need the **signed .apk** from the build (Path A artifact `app-release-signed.apk`,
or Path B's `app-release-signed.apk`).

## Install it

1. Email the .apk to yourself or put it in Google Drive; open it on the phone.
2. Android will warn about installing unknown apps — allow your browser/Files app
   ("Install unknown apps" permission) just this once.
3. Tap Install. The magnolia icon appears in the launcher as **Stanford Herb Shop**.

(If you prefer USB: enable Developer Options → USB debugging, then
`adb install app-release-signed.apk`.)

## What to check

| Check | Expected |
|---|---|
| Launch | Cream splash with the green magnolia tile, then the shop loads full-screen |
| **No browser address bar** | Only true AFTER `/.well-known/assetlinks.json` (with the key's fingerprint) is live on Netlify — until then a grey "Running in Chrome" bar shows. That bar = fingerprint/assetlinks mismatch, not a broken app |
| Status bar | Brand green (#4A7C6B) |
| Search, categories, Dr. Casey's section, wishlist, cart, checkout | All work as on the website |
| External links (if any) | Open with a browser bar over the app — that's correct TWA behavior for other domains |
| Back button | Navigates back through pages, exits from home screen |
| Airplane mode launch | Currently shows a browser error page (no offline cache yet) — known nice-to-have |

## The one gotcha worth repeating

The sideloaded app is signed with YOUR upload key. The Play-installed app will be
signed with GOOGLE's app-signing key. `assetlinks.json` must list BOTH SHA-256
fingerprints (yours now, Google's after the first Play upload) or one of the two
installs shows the URL bar.
