# Netlify deploy — what goes where

All files in this folder go in the **site root** (same folder as index.html), replacing
existing files of the same name:

| File | What it does |
|---|---|
| `manifest.json` | Replaces the current one. Adds `id`/`scope`, dedicated maskable + monochrome icons, brand-cream `background_color` (#F4F1E9). |
| `icon-192.png`, `icon-512.png` | New magnolia launcher icons (replace existing). |
| `icon-192-maskable.png`, `icon-512-maskable.png` | Safe-zone versions for Android's circle/squircle masks. |
| `icon-monochrome-512.png` | Android 13+ themed-icon silhouette. |
| `apple-touch-icon.png` | iPhone home-screen icon (bonus). |

## One edit to index.html

Add these two lines inside `<head>` (the first one is the important one — the manifest
is currently not referenced by the page at all):

```html
<link rel="manifest" href="/manifest.json">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
```

## Still to come (step 3 — after the signing key exists)

- `/.well-known/assetlinks.json` — **required** before the Play app looks right.
  I'll hand you this file with the SHA-256 fingerprint filled in.
- `well-known/assetlinks-TEMPLATE.json` in this folder shows what it will look like.
  Do NOT deploy the template — it has placeholder fingerprints. The real file goes at
  exactly `/.well-known/assetlinks.json` (note the leading dot on the folder).
